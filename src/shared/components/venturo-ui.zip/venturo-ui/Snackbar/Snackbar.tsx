import React, { useEffect, useState } from 'react';
import MuiSnackbar, { SnackbarCloseReason } from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import LinearProgress from '@mui/material/LinearProgress';
import { SnackbarState } from './Snackbar.types';

interface SnackbarProps {
  state: SnackbarState;
  onClose: () => void;
}

export const Snackbar: React.FC<SnackbarProps> = ({ state, onClose }) => {
  const [progress, setProgress] = useState(100);
  const [isPaused, setIsPaused] = useState(false);

  const handleClose = (_event?: React.SyntheticEvent | Event, reason?: SnackbarCloseReason) => {
    if (reason === 'clickaway') {
      return;
    }
    onClose();
  };

  const {
    open,
    message,
    severity = 'success',
    duration = 6000,
    anchorOrigin = { vertical: 'top', horizontal: 'right' },
    showCloseButton = true,
    action,
  } = state;

  // Countdown progress bar with pause on hover
  useEffect(() => {
    if (!open) {
      setProgress(100);
      return;
    }

    // Update progress every 50ms
    const interval = 50;
    const steps = duration / interval;
    const decrement = 100 / steps;

    setProgress(100);

    const timer = setInterval(() => {
      setProgress((prev) => {
        // Pause countdown when hovering
        if (isPaused) {
          return prev;
        }
        const next = prev - decrement;
        return next < 0 ? 0 : next;
      });
    }, interval);

    return () => {
      clearInterval(timer);
    };
  }, [open, duration, isPaused]);

  return (
    <MuiSnackbar
      open={open}
      autoHideDuration={isPaused ? null : duration}
      onClose={handleClose}
      anchorOrigin={anchorOrigin}
    >
      <MuiAlert
        onClose={showCloseButton ? handleClose : undefined}
        severity={severity}
        variant="filled"
        sx={{ width: '100%', position: 'relative', overflow: 'hidden' }}
        action={action}
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {message}
        <LinearProgress
          variant="determinate"
          value={progress}
          sx={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            height: 4,
            backgroundColor: 'rgba(255, 255, 255, 0.3)',
            '& .MuiLinearProgress-bar': {
              backgroundColor: 'rgba(255, 255, 255, 0.8)',
            },
          }}
        />
      </MuiAlert>
    </MuiSnackbar>
  );
};

Snackbar.displayName = 'Snackbar';
